<?php
setcookie("idiomaUsuario");
header('location:pedirIdioma.html');
